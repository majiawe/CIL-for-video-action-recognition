from torchvision import models
from heapq import nsmallest
import numpy as np

b = [5,2,4,7,4,0,0,0]
print(np.nonzero(b))
print(len(np.nonzero(b)[0]))
