import os
import cv2
import sys
import scipy.misc
import numpy as np
from PIL import Image



# tar_path = '/data1/ma_gps/KTH_dataset/frames_edge/'

# for root,dir,file in os.walk(top=data_path):
#     # print(root)
#     # print(dir)
#     # print(file)
#     if len(file) >= 1:
#         for img in file:
#             original_img = cv2.imread('/data1/ma_gps/KTH_dataset/frames_real/running/person09_running_d3_uncomp/img_00115.jpg',0)
#
#             # _,Thr_img = cv2.threshold(original_img,150,255,cv2.THRESH_BINARY)
#             # kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(5,5))
#             # gradient = cv2.morphologyEx(Thr_img,cv2.MORPH_GRADIENT,kernel)
#             # print(gradient)
#             cv2.imshow('frame',original_img)
#             cv2.waitKey(1000)
#             fgbg = cv2.createBackgroundSubtractorMOG2()
#             fgmask = fgbg.apply(original_img)
#             print(fgmask)
#             background = fgbg.getBackgroundImage()
#             cv2.imshow('fgmask',fgmask)
#             sys.exit()




            # img1 = cv2.GaussianBlur(original_img,(3,3),0)
            # canny = cv2.Canny(img1,60,90)

            # cv2.imshow('gradient',canny)
            # cv2.waitKey(100)
            # tar_path = root.replace('frames','frames_edge')

            # if not os.path.exists(tar_path):
            #     os.makedirs(tar_path)
            # scipy.misc.imsave(os.path.join(tar_path, img), canny)


def img_aligned(img):

    mat = np.array(img)
    cen_i = np.rint(mat.shape[0]/2)
    cen_j = np.rint(mat.shape[1]/2)
    mat = cv2.adaptiveThreshold(mat,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,3,0)

    new_mat = np.zeros_like(mat,dtype=np.uint8)
    ind = np.argwhere(mat==255)
    if len(ind) < 1:
        return new_mat
    su = np.sum(ind,axis=0)
    mea = np.rint(su/len(ind))
    i_offset = int(mea[0] - cen_i)
    j_offset = int(mea[1] - cen_j)
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            try:
                new_mat[i,j] = mat[i+i_offset,j+j_offset]
            except:
                continue
    new_mat = cv2.adaptiveThreshold(new_mat, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 3, 0)

    return new_mat


def fillhole(mask):
    _,contours,hierarchy = cv2.findContours(mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    len_contour = len(contours)
    contour_list = []
    for i in range(len_contour):
        drawing = np.zeros_like(mask,dtype=np.uint8)
        img_contour = cv2.drawContours(drawing,contours,i,(255,255,255),-1)
        contour_list.append(img_contour)
    out = sum(contour_list)
    return out

def video_mask(path):
    num = 0

    backsub = cv2.createBackgroundSubtractorMOG2(history=5,varThreshold=20,detectShadows=True)
    capture = cv2.VideoCapture(path)


    threshold = 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2,2))
    while True:
        ret,frame = capture.read()
        if frame is None:
            break
        num += 1

# get the original foreground

        fgmask = backsub.apply(frame)
        cv2.imshow('original_foreground', fgmask)


#  threshold
        _, fgmask = cv2.threshold(fgmask, 0, 255, cv2.THRESH_BINARY)




        # remove isolated pixl
        fgmask, contours, hierarch = cv2.findContours(fgmask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        for i in range(len(contours)):
            area = cv2.contourArea(contours[i])
            if area < threshold:
                fgmask = cv2.drawContours(fgmask, [contours[i]], 0, 0, -1)

        # _, fgmask = cv2.threshold(fgmask, 40, 255, cv2.THRESH_BINARY)
        fgmask = cv2.adaptiveThreshold(fgmask, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 3, 0.1)
        cv2.imshow('adaptive_threshold',fgmask)

        fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, kernel)

        fgmask = img_aligned(fgmask)

        # fill the contours
        # fgmask, contours, hierarch = cv2.findContours(fgmask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        # for i in range(len(contours)):
        #     area = cv2.contourArea(contours[i])
        #     if area > 2:
        #         fgmask = cv2.drawContours(fgmask, [contours[i]], 0, 255, -1)

        fgmask = fillhole(fgmask)
        cv2.imshow('fg mask',fgmask)
        cv2.waitKey(200)
        cls = path.split('/')[5]
        person = path.split('/')[6].split('.')[0]
        # if not os.path.exists(os.path.join('/data1/ma_gps/KTH_dataset/frames_mask/', cls, person)):
        #     os.makedirs(os.path.join('/data1/ma_gps/KTH_dataset/frames_mask/', cls, person))
        # save_img = os.path.join('/data1/ma_gps/KTH_dataset/frames_mask/', cls, person, 'img_{:05d}.jpg'.format(num))
        # cv2.imwrite(save_img, fgmask)

if __name__ == '__main__':
    data_path = '/data1/ma_gps/KTH_dataset/videos/'
    video_mask('/data1/ma_gps/KTH_dataset/videos/handclapping/person01_handclapping_d1_uncomp.avi')
    sys.exit()
    for root,dir,file in os.walk(top=data_path):
        if len(file) > 1:
            for f in file:
                cls = f.split('_')[1]
                if cls == 'handclapping' or 'handwaving':

                    pa = os.path.join(root,f)
                    video_mask(pa)