import numpy as np

a = np.array([[0,23,23],[23,0,0],[0,23,0]])


pirnt