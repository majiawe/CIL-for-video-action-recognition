from DataLoader import dataLoader,DataProcess
from gwr_tool import episodic_gwr,agwr
import pickle


kth = '/data1/ma_gps/KTH_dataset/'
weizmann = '/data1/ma_gps/Weizmann_Dataset/'

data = DataProcess(kth)
# data.train_test_set(ls_cls=['handclapping', 'jogging' ,'running', 'boxing', 'handwaving', 'walking'])

#train_flag = 1: incremental training ,0: batch_training
train_flag = 1


#train_dataset
ds_frame = dataLoader(train=True,frames=True,root=kth,mask_frame='frames',train_path='/home/ma/kth_recognize/KTH_train.pkl',test_path='/home/ma/kth_recognize/KTH_test.pkl')
# ds_flow = dataLoader(train=True,frames=False)




#test_dataset
# frame_test = dataLoader(train=False,frames=True,root=kth,mask_frame='frames',train_path='/home/ma/kth_recognize/KTH_train.pkl',test_path='/home/ma/kth_recognize/KTH_test.pkl')
# flow_test = dataLoader(train=False,frames=False)

e_labels = [6]  #6 for KTH  and  10 for weizam



P1_net = episodic_gwr.EpisodicGWR()
P2_net = episodic_gwr.EpisodicGWR()
P3_net = episodic_gwr.EpisodicGWR()

M1_net = episodic_gwr.EpisodicGWR()
M2_net = episodic_gwr.EpisodicGWR()

ass_net = agwr.AssociativeGWR()


# initiate Posture network 1 and train it
P1_net.init_network(ds=ds_frame,dimension=300,e_labels=e_labels,num_context=4)

all_epoch = [2,2,2,2,2,2]
num_nodes = [400,800,800]
all_thre = [0.024,0.024,0.024,0.024,0.024,0.024]
train_cls = ['handwaving','boxing','handclapping','walking','jogging','running']   # {'handclapping':0,'jogging':1,'running':2,'boxing':3,
                                                                                     # 'handwaving':4,'walking':5}
train_weights = []
weights_label = []
trained_cls = []

for i,cls in enumerate(train_cls):
    trained_cls.append(cls)
    data.train_test_set(ls_cls=cls)
    train_frame = dataLoader(train=True,root=kth,train_path='/home/ma/kth_recognize/KTH_train.pkl',frames=True,mask_frame='frames')
    #train_p1_net
    P1_net.train_egwr(ds_vectors=train_frame,epochs=all_epoch[i],a_threshold=all_thre[i],beta=0.5,l_rates=[0.2,0.08],context=4,regulated=0,train_mode=True ,max_age=10000 )
    P1_net.trained_nodes = P1_net.num_nodes
    P1_net.trained_nodes_ls.append(P1_net.num_nodes)
    #test_p1_net

    if i != 0:
        data.train_test_set(ls_cls=trained_cls)
        te_frame = dataLoader(train=False, root=kth, test_path='/home/ma/kth_recognize/KTH_test.pkl', frames=True, mask_frame='frames')
        p2_w_test,p2_l_test = P1_net.test(ds_vectors=te_frame,test_accuracy=True,pool_size=4,ret_vecs=True)

        print(cls,'p1_net_accuracy', P1_net.test_accuracy)
    else:
        print('************************',i)
    # #create input for p2_net
    # w,l = P1_net.test(ds_vectors=train_frame,ret_vecs=True,pool_size=4)
    # p2_train = list(zip(w,l))
    # p2_test = list(zip(p2_w_test,p2_l_test))
    # #
    # #
    # #initialize_p2_net
    # if i == 0:
    #     P2_net.init_network(ds=p2_train, dimension=128, e_labels=e_labels, num_context=4)
    # #train_p2_net
    # P2_net.train_egwr(ds_vectors=p2_train, epochs=2, a_threshold=0.1, beta=0.5, l_rates=[0.2, 0.08], context=4, regulated=0, train_mode=True)
    # # test_p2_net
    # P2_net.test(ds_vectors=p2_test, test_accuracy=True, pool_size=4)
    # print(cls, 'p2_net_accuracy', P2_net.test_accuracy)

all_test = dataLoader(train=False,frames=True,root=kth,mask_frame='frames',train_path='/home/ma/kth_recognize/kth_train_all.pkl',test_path='/home/ma/kth_recognize/kth_test_all.pkl')
w,l = P1_net.test(ds_vectors=all_test,test_accuracy=True,pool_size=4,ret_vecs=True)
print('p1 final result is ',P1_net.test_accuracy)
p2_all_test = list(zip(w,l))
P2_net.test(ds_vectors=p2_all_test,test_accuracy=True,pool_size=4)
print('p2 final result is',P2_net.test_accuracy)

# with open('p1_net','rb') as f:
#     P1_net = pickle.load(f)
# train_weights,weights_label = P1_net.test(ds_vectors=ds_frame,test_accuracy=True,ret_vecs=True,pool_size=9)
# initiate Posture network 2
P2_train_frame = list(zip(train_weights,weights_label))
p2_test = list(zip(w,l))
P2_net.init_network(ds=P2_train_frame,dimension=100,e_labels=e_labels,num_context=8)
P2_net.train_egwr(ds_vectors=P2_train_frame,epochs=30,a_threshold=0.7,beta=0.5,l_rates=[0.16,0.05],context=3,regulated=0)
train_weights_p2,weights_label_p2 = P2_net.test(ds_vectors=P2_train_frame,test_accuracy=True,ret_vecs=True,pool_size=4)
print('p2_train accuracy',P2_net.test_accuracy)
P2_net.test(ds_vectors=p2_test,test_accuracy=True)
print('p2 test accuracy',P2_net.test_accuracy)
ag_train = list(zip(train_weights_p2,weights_label_p2))

#
#
#
# #initiate a-gwr
M1_net.init_network(ds=ag_train,dimension=25,e_labels=e_labels,num_context=5)
M1_net.train_egwr(ds_vectors=ag_train,epochs=30,a_threshold=0.9,beta=0.5,l_rates=[0.1,0.01],context=5,regulated=0)
M1_net.test(ds_vectors=ag_train,test_accuracy=True)
print(M1_net.test_accuracy)
#
# #initiate M1_net
# M1_net.init_network(ds=ds_flow,dimension=900,e_labels=e_labels,num_context=1)
# M1_net.train_egwr(ds_vectors=ds_flow,epochs=2,a_threshold=0.5,beta=0.7,l_rates=[0.5,0.01],context=1,regulated=0)
#
#
# #create train_set for M2_net
# m2_train_flow,weights_label = M1_net.test(ds_vectors=ds_flow,test_accuracy=True,ret_vecs=True,pool_size=9)
# m2_trian = list(zip(m2_train_flow,weights_label))
#
#
# #train M2_net
# M2_net.init_network(ds=m2_trian,dimension=100,elabels=e_labels,num_context=3)
# M2_net.train_egwr(ds_vectors=m2_trian,epochs=2,a_threshold=0.9,beta=0.7,l_rates=[0.1,0.01],context=3,regulated=0)









#test accuracy
test_weights,test_label = P1_net.test(ds_vectors=frame_test,test_accuracy=True,ret_vecs=True,pool_size=9)
print(P1_net.test_accuracy)
test_ds = list(zip(test_weights,test_label))
test_weights,test_label = P2_net.test(ds_vectors=test_ds,test_accuracy=True,pool_size=4,ret_vecs=True)
print(P2_net.test_accuracy)
test_ds = list(zip(test_weights,test_label))
M1_net.test(ds_vectors=test_ds,test_accuracy=True)
print(M1_net.test_accuracy)